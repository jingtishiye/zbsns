-- -----------------------------
-- 5iSNS MySQL Data Transfer 
-- Part : #1
-- Date : 2020-07-06 15:14:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `5isns_chongzhi`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_chongzhi`;
CREATE TABLE `5isns_chongzhi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `score` int(10) NOT NULL,
  `rmb` int(10) NOT NULL,
  `errorcode` varchar(200) DEFAULT NULL COMMENT '错误代码',
  `trade_no` varchar(200) DEFAULT NULL COMMENT '单号',
  `out_trade_no` varchar(200) DEFAULT NULL COMMENT '商户单号',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1支付宝',
  `actiontype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1充值2打赏',
  `itemid` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1成功',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户充值表';

-- -----------------------------
-- Records of `5isns_chongzhi`
-- -----------------------------
INSERT INTO `5isns_chongzhi` VALUES ('1', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854667');
INSERT INTO `5isns_chongzhi` VALUES ('2', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854668');
INSERT INTO `5isns_chongzhi` VALUES ('3', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854669');
INSERT INTO `5isns_chongzhi` VALUES ('4', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854670');
INSERT INTO `5isns_chongzhi` VALUES ('5', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854670');
INSERT INTO `5isns_chongzhi` VALUES ('6', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854670');
INSERT INTO `5isns_chongzhi` VALUES ('7', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854670');
INSERT INTO `5isns_chongzhi` VALUES ('8', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854670');
INSERT INTO `5isns_chongzhi` VALUES ('9', '1', '20', '2', '', '', '6e01ecdcce83f0c24948df2807f5cef5', '1', '2', '1', '0', '0', '1593854671');
INSERT INTO `5isns_chongzhi` VALUES ('10', '1', '20', '2', '', '', 'fa49ce727bc50144f192d232a828f8f1', '1', '2', '1', '0', '0', '1593855011');
INSERT INTO `5isns_chongzhi` VALUES ('11', '1', '20', '2', '', '', 'fa49ce727bc50144f192d232a828f8f1', '1', '2', '1', '0', '0', '1593855018');
INSERT INTO `5isns_chongzhi` VALUES ('12', '1', '20', '2', '', '', 'abc97c56d9fead1413bc933e41ab3a40', '1', '2', '1', '0', '0', '1593855033');
INSERT INTO `5isns_chongzhi` VALUES ('13', '1', '20', '2', '', '', 'abc97c56d9fead1413bc933e41ab3a40', '1', '2', '1', '0', '0', '1593855069');
INSERT INTO `5isns_chongzhi` VALUES ('14', '3', '10', '1', '', '', 'a2aeb8c1bd3d2450ef619e47b560d049', '1', '1', '0', '0', '0', '1593999482');
INSERT INTO `5isns_chongzhi` VALUES ('15', '3', '1000', '100', '', '', '041c2ec736ed7ec2cd4561e6b4805153', '1', '1', '0', '0', '0', '1594014159');
INSERT INTO `5isns_chongzhi` VALUES ('16', '3', '10000000', '1000000', '', '', '041c2ec736ed7ec2cd4561e6b4805153', '1', '1', '0', '0', '0', '1594014185');
INSERT INTO `5isns_chongzhi` VALUES ('17', '1', '500', '50', '', '', '6966d5b69cf788d5ebe1aab1605e733a', '1', '2', '1', '0', '0', '1594014294');
INSERT INTO `5isns_chongzhi` VALUES ('18', '5', '10000', '1000', '', '', '0bd310f8ed49c0429342e7b2dbd502e8', '1', '1', '0', '0', '0', '1594018236');
INSERT INTO `5isns_chongzhi` VALUES ('19', '1', '2147483647', '2147483647', '', '', '119f8efddb3be66d140c43265b50ea90', '1', '1', '0', '0', '0', '1594018247');
INSERT INTO `5isns_chongzhi` VALUES ('20', '1', '2147483647', '2147483647', '', '', '119f8efddb3be66d140c43265b50ea90', '1', '1', '0', '0', '0', '1594018269');
INSERT INTO `5isns_chongzhi` VALUES ('21', '1', '100000000', '10000000', '', '', '119f8efddb3be66d140c43265b50ea90', '1', '1', '0', '0', '0', '1594018282');
INSERT INTO `5isns_chongzhi` VALUES ('22', '1', '1000000000', '100000000', '', '', '119f8efddb3be66d140c43265b50ea90', '1', '1', '0', '0', '0', '1594018301');
INSERT INTO `5isns_chongzhi` VALUES ('23', '1', '2147483647', '1000000000', '', '', '119f8efddb3be66d140c43265b50ea90', '1', '1', '0', '0', '0', '1594018318');
INSERT INTO `5isns_chongzhi` VALUES ('24', '1', '2147483647', '2147483647', '', '', '172b01a8817ec524e881e6c4992b8a53', '1', '1', '0', '0', '0', '1594018343');
INSERT INTO `5isns_chongzhi` VALUES ('25', '1', '2147483647', '2147483647', '', '', '172b01a8817ec524e881e6c4992b8a53', '1', '1', '0', '0', '0', '1594018372');
INSERT INTO `5isns_chongzhi` VALUES ('26', '1', '2000000000', '200000000', '', '', '172b01a8817ec524e881e6c4992b8a53', '1', '1', '0', '0', '0', '1594018387');
INSERT INTO `5isns_chongzhi` VALUES ('27', '1', '1000000010', '100000001', '', '', '172b01a8817ec524e881e6c4992b8a53', '1', '1', '0', '0', '0', '1594018403');
INSERT INTO `5isns_chongzhi` VALUES ('28', '1', '1000000000', '100000000', '', '', '3454e8ea2202b6db37996e9d8719cf25', '1', '1', '0', '0', '0', '1594018426');

-- -----------------------------
-- Table structure for `5isns_comment`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_comment`;
CREATE TABLE `5isns_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL COMMENT '上级评论',
  `uid` int(11) NOT NULL COMMENT '所属会员',
  `fid` int(11) NOT NULL COMMENT '所属帖子',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1帖子2文档',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `ding` int(11) DEFAULT '0' COMMENT '赞',
  `reply` int(11) DEFAULT '0' COMMENT '回复',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='评论表';


-- -----------------------------
-- Table structure for `5isns_docclass`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_docclass`;
CREATE TABLE `5isns_docclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父id',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `gradeid` varchar(255) NOT NULL DEFAULT '' COMMENT '限制发布的用户组',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档分类表';

-- -----------------------------
-- Records of `5isns_docclass`
-- -----------------------------
INSERT INTO `5isns_docclass` VALUES ('1', '0', '招标信息', '3', '0', '', '1594016379', '1594016542', '0', '0');

-- -----------------------------
-- Table structure for `5isns_doccon`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_doccon`;
CREATE TABLE `5isns_doccon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面id',
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精品',
  `settop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '顶置',
  `praise` int(11) NOT NULL DEFAULT '0' COMMENT '赞',
  `view` int(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `sc` int(11) NOT NULL DEFAULT '0' COMMENT '收藏量',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `down` int(11) NOT NULL DEFAULT '0' COMMENT '下载量',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply` int(11) NOT NULL DEFAULT '0' COMMENT '回复',
  `keywords` varchar(100) NOT NULL COMMENT '关键词',
  `description` varchar(200) NOT NULL COMMENT '描述',
  `fileid` varchar(11) NOT NULL DEFAULT '0' COMMENT '文件id',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `pageid` int(11) NOT NULL DEFAULT '0' COMMENT '页数',
  `showpage` int(11) NOT NULL DEFAULT '2' COMMENT '默认显示页数',
  `raty` varchar(11) NOT NULL DEFAULT '0' COMMENT '评分',
  `ctype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '转换类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `5isns_docslider`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_docslider`;
CREATE TABLE `5isns_docslider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图片id',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1文档链接2外链广告',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '文章的ID或者外链',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档轮播表';


-- -----------------------------
-- Table structure for `5isns_file`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_file`;
CREATE TABLE `5isns_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '我的附件，便于清理附件',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT '我的帖子id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0正常1帖子2文档3话题4会员组5认证材料6空7评论8文章轮播图9文档轮播图10文档封面',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` varchar(100) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` varchar(255) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(10) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(50) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(15) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `width` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `height` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment` char(100) NOT NULL DEFAULT '',
  `score` int(11) NOT NULL DEFAULT '0',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `isimage` tinyint(1) NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文件表';


-- -----------------------------
-- Table structure for `5isns_jubao`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_jubao`;
CREATE TABLE `5isns_jubao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '所属会员',
  `fid` int(11) NOT NULL COMMENT '帖子文档用户',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0用户1帖子2文档',
  `reason` tinyint(1) NOT NULL DEFAULT '1' COMMENT '原因',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='举报表';


-- -----------------------------
-- Table structure for `5isns_menu`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_menu`;
CREATE TABLE `5isns_menu` (
  `keyname` char(20) NOT NULL COMMENT 'ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `controller` char(255) NOT NULL DEFAULT '' COMMENT 'controller',
  `action` char(255) NOT NULL DEFAULT '' COMMENT 'action',
  `is_hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`keyname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='菜单表';

-- -----------------------------
-- Records of `5isns_menu`
-- -----------------------------
INSERT INTO `5isns_menu` VALUES ('chongzhilist', '现金消费记录', '1', '3', 'records', 'chongzhi', 'list', '0', 'fa-database', '1', '1491837214', '0');
INSERT INTO `5isns_menu` VALUES ('configsetting', '系统配置', '1', '6', 'system', 'config', 'setting', '0', 'fa-cogs', '1', '1491668183', '0');
INSERT INTO `5isns_menu` VALUES ('databaseimportlist', '还原数据', '1', '0', 'system', 'database', 'importlist', '0', 'fa-undo', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('databaselist', '备份数据', '1', '1', 'system', 'database', 'list', '0', 'fa-inbox', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('docclasslist', '文档分类', '1', '5', 'docs', 'docclass', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('doclist', '文档列表', '1', '5', 'docs', 'doc', 'list', '0', 'fa-file-o', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('docs', '文档管理', '0', '7', 'docs', '', '', '0', 'fa-file-word-o', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('docsliderlist', '文档轮播图', '1', '5', 'docs', 'docslider', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('doc_commentlist', '文档评论', '1', '5', 'docs', 'doc_comment', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('expand', '扩展管理', '0', '7', 'expand', '', '', '0', 'fa-linode', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('front', '前台设置', '0', '8', 'front', '', '', '0', 'fa-laptop', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('jubaolist', '举报记录', '1', '2', 'records', 'jubao', 'list', '0', 'fa-volume-up', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('messagelist', '消息记录', '1', '2', 'records', 'message', 'list', '0', 'fa-volume-up', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('moduleslist', '模块列表', '1', '5', 'expand', 'modules', 'list', '0', 'fa-file-o', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('navlist', '前台导航', '1', '4', 'front', 'nav', 'list', '0', 'fa-hand-o-right', '1', '1491668183', '0');
INSERT INTO `5isns_menu` VALUES ('pluginslist', '插件列表', '1', '5', 'expand', 'plugins', 'list', '0', 'fa-file-o', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('pointnotelist', '积分记录', '1', '3', 'records', 'pointnote', 'list', '0', 'fa-database', '1', '1491837214', '0');
INSERT INTO `5isns_menu` VALUES ('pointrulelist', '积分规则', '1', '5', 'system', 'pointrule', 'list', '0', 'fa-align-justify', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('records', '记录管理', '0', '6', 'records', '', '', '0', 'fa-bar-chart', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('rzuserlist', '会员审核', '1', '1', 'users', 'rzuser', 'list', '0', 'fa-id-card', '1', '1492000451', '0');
INSERT INTO `5isns_menu` VALUES ('syscache', '清理缓存', '1', '0', 'system', 'sys', 'cache', '0', 'fa-sign-language', '1', '1491668183', '0');
INSERT INTO `5isns_menu` VALUES ('system', '系统管理', '0', '10', 'system', '', '', '0', 'fa-wrench', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('tixianlist', '提现记录', '1', '3', 'records', 'tixian', 'list', '0', 'fa-database', '1', '1491837214', '0');
INSERT INTO `5isns_menu` VALUES ('topiccatelist', '话题列表', '1', '5', 'front', 'topiccate', 'list', '0', 'fa-th-large', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('topicclasslist', '文章分类', '1', '5', 'topics', 'topicclass', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('topiclist', '文章列表', '1', '5', 'topics', 'topic', 'list', '0', 'fa-file-o', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('topics', '帖子管理', '0', '7', 'topics', '', '', '0', 'fa-file-text-o', '1', '1491578008', '9');
INSERT INTO `5isns_menu` VALUES ('topicsliderlist', '文章轮播图', '1', '5', 'topics', 'topicslider', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('topic_commentlist', '文章评论', '1', '5', 'topics', 'topic_comment', 'list', '0', 'fa-comments', '1', '1491318724', '0');
INSERT INTO `5isns_menu` VALUES ('trashlist', '回收站', '1', '2', 'system', 'trash', 'list', '0', 'fa-recycle', '1', '1492320214', '1492311462');
INSERT INTO `5isns_menu` VALUES ('usergradelist', '会员等级', '1', '2', 'users', 'usergrade', 'list', '0', 'fa-signal', '1', '1491837214', '0');
INSERT INTO `5isns_menu` VALUES ('userlist', '会员列表', '1', '3', 'users', 'user', 'list', '0', 'fa-user', '1', '1491837214', '0');
INSERT INTO `5isns_menu` VALUES ('users', '用户管理', '0', '9', 'users', '', '', '0', 'fa-group', '1', '1491578008', '9');

-- -----------------------------
-- Table structure for `5isns_message`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_message`;
CREATE TABLE `5isns_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '所属会员',
  `touid` int(11) NOT NULL DEFAULT '0' COMMENT '发送对象',
  `type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1系统消息2私信',
  `content` text NOT NULL COMMENT '内容',
  `id_to_id` varchar(100) NOT NULL COMMENT '对话',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态2表示已读',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='消息表';

-- -----------------------------
-- Records of `5isns_message`
-- -----------------------------
INSERT INTO `5isns_message` VALUES ('1', '0', '2', '1', '感谢你的举报，我们将积极处理该举报内容。', '', '1', '0', '1594019431');
INSERT INTO `5isns_message` VALUES ('2', '0', '2', '1', '感谢你的举报，我们将积极处理该举报内容。', '', '1', '0', '1594019509');

-- -----------------------------
-- Table structure for `5isns_nav`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_nav`;
CREATE TABLE `5isns_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` tinyint(3) unsigned NOT NULL COMMENT '顶部还是底部',
  `name` varchar(20) NOT NULL COMMENT '导航名称',
  `alias` varchar(20) DEFAULT '' COMMENT '导航别称',
  `link` varchar(255) DEFAULT '' COMMENT '导航链接',
  `icon` varchar(255) DEFAULT '' COMMENT '导航图标',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='导航表';

-- -----------------------------
-- Records of `5isns_nav`
-- -----------------------------
INSERT INTO `5isns_nav` VALUES ('1', '1', '招标信息', 'topics', 'index,topics', '', '_self', '1', '0', '1594016320', '0');
INSERT INTO `5isns_nav` VALUES ('2', '1', '文档', 'docs', 'index,docs', '', '_self', '0', '0', '1594016296', '0');
INSERT INTO `5isns_nav` VALUES ('3', '1', '话题', 'tags', 'tags-taglist,index', '', '_self', '0', '0', '1594016297', '0');

-- -----------------------------
-- Table structure for `5isns_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_plugins`;
CREATE TABLE `5isns_plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '插件文件名',
  `cnname` varchar(100) NOT NULL DEFAULT '' COMMENT '插件中文名称',
  `author` varchar(100) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(100) NOT NULL DEFAULT '' COMMENT '版本',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '插件描述',
  `config` text COMMENT '配置数据',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='插件表';


-- -----------------------------
-- Table structure for `5isns_point_note`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_point_note`;
CREATE TABLE `5isns_point_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `inctype` char(1) NOT NULL DEFAULT '+',
  `score` int(10) NOT NULL,
  `itemid` varchar(11) NOT NULL DEFAULT '0' COMMENT '表示帖子或者其他各种类型的主键id',
  `to_uid` varchar(11) NOT NULL DEFAULT '0' COMMENT '规则id或者受益人uid',
  `scoretype` varchar(30) NOT NULL DEFAULT '' COMMENT '积分类型',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1下载附件2下载文档3付费阅读4充值5购买会员6打赏7提现8积分规则',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `description` varchar(200) NOT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `5isns_point_note`
-- -----------------------------
INSERT INTO `5isns_point_note` VALUES ('1', '2', '-', '0', '1', '1', 'point', '3', '1593855044', '0', '1', '付费阅读帖子《餐饮云服首创商厨新零售模式，个性设计加直选采购单》');
INSERT INTO `5isns_point_note` VALUES ('2', '1', '+', '0', '1', '2', 'point', '3', '1593855044', '0', '1', '付费阅读帖子《餐饮云服首创商厨新零售模式，个性设计加直选采购单》');
INSERT INTO `5isns_point_note` VALUES ('3', '3', '-', '0', '1', '1', 'point', '3', '1594014025', '0', '1', '付费阅读帖子《餐饮云服首创商厨新零售模式，个性设计加直选采购单》');
INSERT INTO `5isns_point_note` VALUES ('4', '1', '+', '0', '1', '3', 'point', '3', '1594014026', '0', '1', '付费阅读帖子《餐饮云服首创商厨新零售模式，个性设计加直选采购单》');
INSERT INTO `5isns_point_note` VALUES ('5', '1', '-', '0', '3', '0', 'point', '5', '1594014177', '0', '1', '购买会员组信息发布');
INSERT INTO `5isns_point_note` VALUES ('6', '4', '-', '0', '3', '0', 'point', '5', '1594014422', '0', '1', '购买会员组信息发布');
INSERT INTO `5isns_point_note` VALUES ('7', '3', '-', '20', '2', '1', 'point', '3', '1594019219', '0', '1', '付费阅读帖子《付费信息最新》');
INSERT INTO `5isns_point_note` VALUES ('8', '1', '+', '20', '2', '3', 'point', '3', '1594019219', '0', '1', '付费阅读帖子《付费信息最新》');

-- -----------------------------
-- Table structure for `5isns_point_rule`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_point_rule`;
CREATE TABLE `5isns_point_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则ID',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '规则名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1为增加2为减少',
  `score` varchar(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `num` varchar(11) NOT NULL DEFAULT '0' COMMENT '二十四小时奖赏次数',
  `tasknum` varchar(11) NOT NULL DEFAULT '0' COMMENT '奖赏次数',
  `scoretype` varchar(30) NOT NULL DEFAULT '' COMMENT '积分类型',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `description` varchar(200) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='积分规则表';

-- -----------------------------
-- Records of `5isns_point_rule`
-- -----------------------------
INSERT INTO `5isns_point_rule` VALUES ('1', 'docadd', '1', '20', '0', '0', 'point', '1594019619', '0', '1', '');
INSERT INTO `5isns_point_rule` VALUES ('2', 'yaoqing', '1', '10', '0', '0', 'point', '1594019650', '0', '1', '');

-- -----------------------------
-- Table structure for `5isns_raty_user`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_raty_user`;
CREATE TABLE `5isns_raty_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `score` int(10) NOT NULL,
  `itemid` int(11) NOT NULL COMMENT '文档id',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `5isns_rzuser`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_rzuser`;
CREATE TABLE `5isns_rzuser` (
  `uid` int(11) NOT NULL COMMENT '会员',
  `mobile` varchar(200) DEFAULT NULL COMMENT '联系方式',
  `name` varchar(200) DEFAULT NULL COMMENT '真实姓名',
  `statusdes` varchar(200) DEFAULT NULL COMMENT '认证描述',
  `idcard` varchar(32) NOT NULL COMMENT '身份证或机构代码证',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '证件照片',
  `keywords` varchar(200) DEFAULT NULL COMMENT '关键词',
  `rzdescrib` varchar(200) DEFAULT NULL COMMENT '关键词',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1个人2企业',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1通过',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户认证表';


-- -----------------------------
-- Table structure for `5isns_searchword`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_searchword`;
CREATE TABLE `5isns_searchword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '热搜关键词',
  `uid` int(10) NOT NULL,
  `num` int(20) NOT NULL DEFAULT '1' COMMENT '搜索次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户热搜表';


-- -----------------------------
-- Table structure for `5isns_tagsandother`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_tagsandother`;
CREATE TABLE `5isns_tagsandother` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '话题名称',
  `tid` int(11) NOT NULL COMMENT '话题id',
  `did` int(11) NOT NULL COMMENT '管理目标id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '关联目标类型0用户1帖子2文档',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `5isns_tagsandother`
-- -----------------------------
INSERT INTO `5isns_tagsandother` VALUES ('1', '招标信息', '1', '1', '1', '0', '0', '1');
INSERT INTO `5isns_tagsandother` VALUES ('2', '招标信息', '1', '2', '1', '0', '0', '1');

-- -----------------------------
-- Table structure for `5isns_tixian`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_tixian`;
CREATE TABLE `5isns_tixian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `score` int(11) NOT NULL DEFAULT '0',
  `rmb` varchar(100) NOT NULL DEFAULT '' COMMENT '金额',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '账号',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1支付宝',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '申请时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '通过时间',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='提现表';


-- -----------------------------
-- Table structure for `5isns_topic`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_topic`;
CREATE TABLE `5isns_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户',
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1单页2帖子3视频',
  `free` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0免费1付费2部分收费',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '付费积分',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精贴',
  `settop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '顶置',
  `sc` int(11) NOT NULL DEFAULT '0' COMMENT '收藏',
  `view` int(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `img_num` int(11) NOT NULL DEFAULT '0' COMMENT '图片数量',
  `file_num` int(11) NOT NULL DEFAULT '0' COMMENT '附件数量',
  `filelist` text COMMENT '附件列表',
  `first_img` varchar(100) DEFAULT NULL COMMENT '首图片',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply` int(11) NOT NULL DEFAULT '0' COMMENT '回复',
  `keywords` varchar(200) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `5isns_topic`
-- -----------------------------
INSERT INTO `5isns_topic` VALUES ('1', '1', '0', '2', '2', '50', '餐饮云服首创商厨新零售模式，个性设计加直选采购单', '1', '1', '0', '57', '0', '0', '', '', '1', '1594016751', '1593854511', '0', '招标信息', '个人个人人格热格格热狗GRE供热隔热管仍然个激怒有酷酷教育厅教育厅教育厅核桃仁和投入核桃仁挂号费功夫很过分和规范化鼓风机御景园风神股份道森股份割发代首股份第三个发的是割发代首割发代首刚发的食管腹段刚发的是割发代首提供原合同御景华庭', '<p><br></p><p></p><p>个人个人人格热格格热狗GRE供热隔热管仍然个激怒有酷酷教育厅教育厅教育厅核桃仁和投入核桃仁<br><br></p><hr class="hidecontent"><p>挂号费功夫很过分和规范化鼓风机御景园风神股份道森股份割发代首股份第三个发的是割发代首割发代首刚发的食管腹段刚发的是割发代首提供原合同御景华庭</p>');
INSERT INTO `5isns_topic` VALUES ('2', '1', '0', '2', '2', '20', '付费信息最新', '0', '0', '0', '7', '0', '0', '', '', '1', '0', '1594019183', '0', '招标信息', '最初用于发动机冷却是用水，多数为蒸馏水！起到热传导作用！中文名水冷液作用热传导雏形用于发动机冷却是用水特点长期高温下不变质不产生明显杂质在电脑里面水冷液也是起到热传导的用处。只要能做到长期高温下不变质不产生明显杂质不腐蚀冷头/冷排即可，至于沸点高冰点低的指标实际使用没太大意义，而且相对于比较贵的水冷', '<p><br></p><p></p><p><span style="color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; text-indent: 28px;">最初用于发动机冷却是用水，多数为蒸馏水！起到热传导作用！</span><br><br></p><hr class="hidecontent"><div class="lemma-summary" label-module="lemmaSummary" style="clear: both; overflow-wrap: break-word; color: rgb(51, 51, 51); margin-bottom: 15px; text-indent: 2em; line-height: 24px; zoom: 1; font-family: arial, 宋体, sans-serif;"><div class="para" label-module="para" style="overflow-wrap: break-word; margin-bottom: 15px; text-indent: 2em; line-height: 24px; zoom: 1;"><br></div></div><div class="lemmaWgt-promotion-leadPVBtn" style="color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px;"></div><div class="configModuleBanner" style="color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px;"></div><div class="basic-info cmn-clearfix" style="margin: 20px 0px 35px; clear: both; background-image: url(&quot;https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/basicInfo/img/basicInfo-bg_ccaff81.png&quot;); background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(51, 51, 51); font-family: arial, 宋体, sans-serif; font-size: 12px;"><dl class="basicInfo-block basicInfo-left" style="margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px; width: 395px; float: left;"><dt class="basicInfo-item name" style="margin: 0px; padding: 0px 5px 0px 12px; line-height: 26px; float: left; width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; overflow-wrap: normal; color: rgb(153, 153, 153);">中文名</dt><dd class="basicInfo-item value" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; line-height: 26px; float: left; zoom: 1; width: 285px; position: relative; word-break: break-all;">水冷液</dd><dt class="basicInfo-item name" style="margin: 0px; padding: 0px 5px 0px 12px; line-height: 26px; float: left; width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; overflow-wrap: normal; color: rgb(153, 153, 153);">作&nbsp;&nbsp;&nbsp;&nbsp;用</dt><dd class="basicInfo-item value" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; line-height: 26px; float: left; zoom: 1; width: 285px; position: relative; word-break: break-all;">热传导</dd></dl><dl class="basicInfo-block basicInfo-right" style="margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px; width: 395px; float: left;"><dt class="basicInfo-item name" style="margin: 0px; padding: 0px 5px 0px 12px; line-height: 26px; float: left; width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; overflow-wrap: normal; color: rgb(153, 153, 153);">雏&nbsp;&nbsp;&nbsp;&nbsp;形</dt><dd class="basicInfo-item value" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; line-height: 26px; float: left; zoom: 1; width: 285px; position: relative; word-break: break-all;">用于发动机冷却是用水</dd><dt class="basicInfo-item name" style="margin: 0px; padding: 0px 5px 0px 12px; line-height: 26px; float: left; width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; overflow-wrap: normal; color: rgb(153, 153, 153);">特&nbsp;&nbsp;&nbsp;&nbsp;点</dt><dd class="basicInfo-item value" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; padding: 0px; line-height: 26px; float: left; zoom: 1; width: 285px; position: relative; word-break: break-all;">长期高温下不变质不产生明显杂质</dd></dl></div><div class="para" label-module="para" style="overflow-wrap: break-word; color: rgb(51, 51, 51); margin-bottom: 15px; text-indent: 2em; line-height: 24px; zoom: 1; font-family: arial, 宋体, sans-serif;"><div class="lemma-picture text-pic layout-right" style="border: 1px solid rgb(224, 224, 224); overflow: hidden; margin: 0px 0px 3px; position: relative; float: right; clear: right; width: 220px;"><a class="image-link" nslog-type="9317" href="https://baike.baidu.com/pic/%E6%B0%B4%E5%86%B7%E6%B6%B2/9833189/0/55a628d1078cfc2b9b502792?fr=lemma&amp;ct=single" target="_blank" title="" style="color: rgb(19, 110, 194); display: block; width: 220px; height: 165px;"><img class="" src="https://bkimg.cdn.bcebos.com/pic/902397dda144ad347120f7a4d0a20cf431ad8571?x-bce-process=image/resize,m_lfit,w_220,h_220,limit_1" alt="" style="display: block; margin: 0px auto; width: 220px; height: 165px;"></a></div></div><div class="para" label-module="para" style="overflow-wrap: break-word; color: rgb(51, 51, 51); margin-bottom: 15px; text-indent: 2em; line-height: 24px; zoom: 1; font-family: arial, 宋体, sans-serif;">在电脑里面水冷液也是起到热传导的用处。只要能做到长期高温下不变质不产生明显杂质不腐蚀冷头/冷排即可，至于沸点高冰点低的指标实际使用没太大意义，而且相对于比较贵的水冷液，汽车防冻液也可以替代。</div>');

-- -----------------------------
-- Table structure for `5isns_topiccate`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_topiccate`;
CREATE TABLE `5isns_topiccate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '话题ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父id',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '话题名称',
  `gradeid` varchar(255) NOT NULL DEFAULT '' COMMENT '限制发布的用户组',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐话题',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '话题描述',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '话题图片id',
  `characters` varchar(10) NOT NULL COMMENT '所属字母',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `doc_num` int(11) NOT NULL DEFAULT '0' COMMENT '文档数量',
  `topic_num` int(11) NOT NULL DEFAULT '0' COMMENT '帖子数量',
  `user_num` int(11) NOT NULL DEFAULT '0' COMMENT '关注数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='话题表';

-- -----------------------------
-- Records of `5isns_topiccate`
-- -----------------------------
INSERT INTO `5isns_topiccate` VALUES ('1', '0', '0', '2', '招标信息', '3', '0', '', '0', 'A', '1594016243', '0', '1', '0', '0', '2', '0');

-- -----------------------------
-- Table structure for `5isns_topicclass`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_topicclass`;
CREATE TABLE `5isns_topicclass` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父id',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `gradeid` varchar(255) NOT NULL DEFAULT '' COMMENT '限制发布的用户组',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='话题表';

-- -----------------------------
-- Records of `5isns_topicclass`
-- -----------------------------
INSERT INTO `5isns_topicclass` VALUES ('1', '0', '招标信息', '3', '0', '', '1594016536', '0', '1', '0');

-- -----------------------------
-- Table structure for `5isns_topicslider`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_topicslider`;
CREATE TABLE `5isns_topicslider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图片id',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1文章链接2外链广告',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '文章的ID或者外链',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文章轮播表';


-- -----------------------------
-- Table structure for `5isns_user`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_user`;
CREATE TABLE `5isns_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userip` varchar(32) NOT NULL COMMENT 'IP',
  `nickname` char(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` varchar(32) NOT NULL COMMENT '名称',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `avatar` int(11) DEFAULT '0' COMMENT '头像',
  `usermail` varchar(32) NOT NULL COMMENT '邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机',
  `regtime` varchar(32) NOT NULL COMMENT '注册时间',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '正常',
  `rz` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否认证,什么认证类型',
  `statusdes` varchar(200) DEFAULT NULL COMMENT '认证描述',
  `userhome` varchar(32) DEFAULT NULL COMMENT '家乡',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `last_login_time` varchar(20) DEFAULT '0' COMMENT '最后登陆时间',
  `last_login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP',
  `salt` varchar(20) DEFAULT NULL COMMENT 'salt',
  `logins` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登錄次數',
  `leader_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '上级会员ID',
  `is_inside` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为后台使用者',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE,
  UNIQUE KEY `usermail` (`usermail`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- -----------------------------
-- Records of `5isns_user`
-- -----------------------------
INSERT INTO `5isns_user` VALUES ('1', '2071028591', 'admin', 'admin', 'a9d32f7775cfb7728dfa6338736e52e9', '0', 'admin@admin.com', '', '1593853331', '0', '1', '0', '', '', '', '1594013656', '2071028591', 'QZZ7YDJS5VUW7PT3', '62', '1', '1');
INSERT INTO `5isns_user` VALUES ('2', '2071028591', '123123', '123123', '82e8fdf36cf723ddb37d685158a60d4e', '0', '123@123.com', '', '1593854657', '0', '1', '0', '', '', '', '1594019268', '2071028591', 'R4HKZPC6HZB8X6TH', '3', '1', '0');
INSERT INTO `5isns_user` VALUES ('3', '2071028591', '123', '123', 'e72743af26250dab9fb629fcd50dd7e2', '1593999444', '123@qq.com', '', '1593999365', '0', '1', '0', '', '', '', '1594019084', '2071028591', '383UH8PGPNQNXRSN', '5', '1', '0');
INSERT INTO `5isns_user` VALUES ('4', '2071028591', 'xinxi', 'xinxi', '48b33a31db245c1fc4a40ac211ef605e', '0', 'xinxi@1.com', '', '1594014390', '0', '1', '0', '', '', '', '1594014390', '2071028591', '3HSU7AEGES2K7WVX', '1', '1', '0');
INSERT INTO `5isns_user` VALUES ('5', '2071028591', '456', '456', '9b1cc635ed8b4a71a01ad0723991c7b6', '0', '456@qq.com', '', '1594014673', '0', '1', '0', '', '', '', '1594014673', '2071028591', '5MCHM4DMP4B92FRJ', '1', '1', '0');

-- -----------------------------
-- Table structure for `5isns_user_extend`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_user_extend`;
CREATE TABLE `5isns_user_extend` (
  `uid` int(11) NOT NULL COMMENT '会员',
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `expoint1` int(11) DEFAULT '0' COMMENT '扩展积分1',
  `expoint2` int(11) DEFAULT '0' COMMENT '扩展积分2',
  `expoint3` int(11) DEFAULT '0' COMMENT '扩展积分3',
  `doc_num` int(11) DEFAULT '0' COMMENT '文档数量',
  `topic_num` int(11) DEFAULT '0' COMMENT '帖子数量',
  `fensi_num` int(11) DEFAULT '0' COMMENT '粉丝数量',
  `cate_num` int(11) DEFAULT '0' COMMENT '我的话题数量',
  `focus_mydoc_num` int(11) DEFAULT '0' COMMENT '被收藏文档数量',
  `focus_mytopic_num` int(11) DEFAULT '0' COMMENT '被收藏帖子数量',
  `focus_mycate_num` int(11) DEFAULT '0' COMMENT '被关注话题数量',
  `focus_user_num` int(11) DEFAULT '0' COMMENT '关注用户数量',
  `focus_doc_num` int(11) DEFAULT '0' COMMENT '收藏文档数量',
  `focus_topic_num` int(11) DEFAULT '0' COMMENT '收藏帖子数量',
  `focus_cate_num` int(11) DEFAULT '0' COMMENT '关注话题数量',
  `grades` tinyint(1) NOT NULL DEFAULT '0' COMMENT '购买等级',
  `grades_days` int(11) DEFAULT '-1' COMMENT '天数',
  `grades_nums` int(11) DEFAULT '-1' COMMENT '次数',
  `grades_bili` int(11) NOT NULL DEFAULT '0' COMMENT '比例涉及付费内容|下载附件|下载文档',
  `grades_limittime` varchar(255) NOT NULL DEFAULT '0' COMMENT '时间限制',
  `grades_type` varchar(255) NOT NULL DEFAULT '0' COMMENT '权限',
  `grades_name` varchar(100) DEFAULT NULL COMMENT '购买等级名称',
  `grades_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '购买更新时间',
  `up_grades` tinyint(1) NOT NULL DEFAULT '0' COMMENT '升级等级',
  `up_grades_bili` int(11) NOT NULL DEFAULT '0' COMMENT '比例涉及付费内容|下载附件|下载文档',
  `up_grades_limittime` varchar(255) NOT NULL DEFAULT '0' COMMENT '时间限制',
  `up_grades_type` varchar(255) NOT NULL DEFAULT '0' COMMENT '权限',
  `up_grades_name` varchar(100) DEFAULT NULL COMMENT '升级等级名称',
  `up_grades_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '升级更新时间',
  `keywords` varchar(200) DEFAULT NULL COMMENT '关键词',
  `notify_set` text COMMENT '请求数据',
  `mailstatus` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '邮箱是否认证',
  `mobilestatus` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '手机是否认证',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1通过',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户附加信息表';

-- -----------------------------
-- Records of `5isns_user_extend`
-- -----------------------------
INSERT INTO `5isns_user_extend` VALUES ('1', '20', '0', '0', '0', '0', '2', '0', '0', '0', '0', '0', '0', '0', '0', '0', '3', '0', '0', '100', '0,0,0,0', '1,2,4,5,6', '信息发布', '1594014177', '2', '100', '0,0,0,0', '4,5,6', '普通会员', '1593853418', '', '', '0', '0', '0', '0', '0');
INSERT INTO `5isns_user_extend` VALUES ('2', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '0', '0', '', '0', '2', '100', '0,0,0,0', '4,5,6', '普通会员', '1593854658', '', '', '0', '0', '0', '0', '0');
INSERT INTO `5isns_user_extend` VALUES ('3', '4980', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '0', '0', '', '0', '2', '100', '0,0,0,0', '4,5,6', '普通会员', '1593999366', '', '', '0', '0', '0', '0', '0');
INSERT INTO `5isns_user_extend` VALUES ('4', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '3', '0', '0', '100', '0,0,0,0', '1,2,4,5,6', '信息发布', '1594014422', '2', '100', '0,0,0,0', '4,5,6', '普通会员', '1594014391', '', '', '0', '0', '0', '0', '0');
INSERT INTO `5isns_user_extend` VALUES ('5', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '0', '0', '', '0', '2', '100', '0,0,0,0', '4,5,6', '普通会员', '1594014675', '', '', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `5isns_usergrade`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_usergrade`;
CREATE TABLE `5isns_usergrade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL COMMENT '名称',
  `score` int(11) NOT NULL COMMENT '等级所需积分',
  `gmtype` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1购买2升级',
  `type` varchar(32) NOT NULL DEFAULT '0' COMMENT '1发帖2发文档3回帖4查看付费内容5下载附件6下载文档',
  `days` int(11) NOT NULL DEFAULT '0' COMMENT '天数涉及查看付费内容|下载附件|下载文档',
  `nums` int(11) NOT NULL DEFAULT '0' COMMENT '次数涉及下载附件|下载文档',
  `bili` int(11) NOT NULL DEFAULT '0' COMMENT '比例涉及付费内容|下载附件|下载文档',
  `limittime` varchar(255) NOT NULL DEFAULT '0' COMMENT '时间涉及发帖|发文档|回帖|下载',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级图标id',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员等级表';

-- -----------------------------
-- Records of `5isns_usergrade`
-- -----------------------------
INSERT INTO `5isns_usergrade` VALUES ('2', '普通会员', '0', '2', '4,5,6', '0', '0', '100', '0,0,0,0', '0', '1', '1556592145', '1594014010');
INSERT INTO `5isns_usergrade` VALUES ('3', '信息发布', '1000000', '1', '1,2,4,5,6', '0', '0', '100', '0,0,0,0', '0', '1', '1594014046', '1594016059');

-- -----------------------------
-- Table structure for `5isns_usersandother`
-- -----------------------------
DROP TABLE IF EXISTS `5isns_usersandother`;
CREATE TABLE `5isns_usersandother` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '名称',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `did` int(11) NOT NULL COMMENT '管理目标id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '关联目标类型0用户1帖子2话题3文档4消息5评论点赞',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

